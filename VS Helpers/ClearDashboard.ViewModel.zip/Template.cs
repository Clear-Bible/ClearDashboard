﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClearDashboard.Common;
using ClearDashboard.Common.Models;
using ClearDashboard.DAL;

namespace $rootnamespace$
{
    /// <summary>
    /// 
    /// </summary>
    public class $safeitemname$ : BindableBase
    {
        #region Member Variables
    
        #endregion //Member Variables

        #region Public Properties

        #endregion //Public Properties

        #region Observable Properties

        #endregion //Observable Properties

        #region Constructor

        #endregion //Constructor

        #region Methods

        #endregion // Methods

    }
}

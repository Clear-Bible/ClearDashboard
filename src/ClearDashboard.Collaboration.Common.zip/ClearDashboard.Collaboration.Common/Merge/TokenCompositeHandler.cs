﻿using System;
using System.Linq.Expressions;
using ClearDashboard.Collaboration.DifferenceModel;
using ClearDashboard.Collaboration.Model;
using Models = ClearDashboard.DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Logging;
using ClearDashboard.DataAccessLayer.Data;
using ClearDashboard.DataAccessLayer.Models;
using ClearDashboard.Collaboration.Exceptions;

namespace ClearDashboard.Collaboration.Merge;

public class TokenCompositeHandler : DefaultMergeHandler
{
    public TokenCompositeHandler(MergeContext mergeContext) : base(mergeContext)
    {
        mergeContext.MergeBehavior.AddEntityTypeDiscriminatorMapping(
            entityType: typeof(Models.TokenComposite),
            (TableEntityType: typeof(Models.TokenComponent), DiscriminatorColumnName: "Discriminator", DiscriminatorColumnValue: "TokenComposite")
        );
        mergeContext.MergeBehavior.AddEntityTypeDiscriminatorMapping(
            entityType: typeof(Models.Token),
            (TableEntityType: typeof(Models.TokenComponent), DiscriminatorColumnName: "Discriminator", DiscriminatorColumnValue: "Token")
        );

        mergeContext.MergeBehavior.AddEntityValueResolver(
            (typeof(Models.TokenComposite), nameof(Models.TokenComposite.VerseRowId)),
            entityValueResolver: (IModelSnapshot modelSnapshot, ProjectDbContext projectDbContext, MergeCache cache, ILogger logger) => {

                if (modelSnapshot.EntityPropertyValues.TryGetValue("VerseRowLocation", out var verseRowLocation) &&
                    modelSnapshot.EntityPropertyValues.TryGetValue("TokenizedCorpusId", out var tokenizedCorpusId))
                {
                    var verseRowId = projectDbContext.VerseRows
                        .Where(e => (Guid)e.TokenizedCorpusId == (Guid)tokenizedCorpusId!)
                        .Where(e => (string)e.BookChapterVerse! == (string)verseRowLocation!)
                        .Select(e => e.Id)
                        .FirstOrDefault();

                    logger.LogInformation($"Converted TokenComposite TokenizedCorpusId ('{tokenizedCorpusId}') / VerseRowLocation ('{verseRowLocation}') to VerseRowId ('{verseRowId}')");
                    return verseRowId;
                }
                else
                {
                    throw new PropertyResolutionException($"TokenComposite snapshot does not have both TokenizedCorpusId+VerseRowId, which are required for VerseRowLocation conversion.");
                }

            });

        mergeContext.MergeBehavior.AddPropertyNameMapping(
            (typeof(Models.TokenComposite), "VerseRowLocation"),
            new[] { nameof(Models.TokenComposite.VerseRowId) });

        mergeContext.MergeBehavior.AddPropertyNameMapping(
            (typeof(Models.TokenComposite), "TokenLocations"),
            Enumerable.Empty<string>());
    }

    // FIXME:  need to talk out this logic with someone.  I think what I need to do
    // is approach this at a low level - no business logic - and assume that the
    // snapshot carries across changes to affected Translations and Alignments.

    protected override async Task HandleDeleteAsync<T>(T itemToDelete, CancellationToken cancellationToken)
    {
        await base.HandleDeleteAsync(itemToDelete, cancellationToken);
    }

    protected override async Task<Guid> HandleCreateAsync<T>(T itemToCreate, CancellationToken cancellationToken)
    {
        await base.HandleCreateAsync(itemToCreate, cancellationToken);

        if (typeof(T).IsAssignableTo(typeof(IModelSnapshot<Models.TokenComposite>)))
        {
            // FIXME:
            // Not only do we need to create the TokenComposite record itself,
            // but we also need to find all TokenLocation tokens and set their
            // TokenCompositeId.

            throw new NotImplementedException($"FIXME:  Need to add assigning Tokens to TokenComposite as part of HandleCreate");
        }
        else
        {
            throw new NotImplementedException($"Derived merge handler with '{typeof(T).ShortDisplayName()}' model-specific HandleModifyProperties functionality");
        }
    }

    public static ProjectDbContextMergeQueryAsync GetDeleteCompositesByVerseRowIdQuery(Guid verseRowId)
    {
        /*
         * Query to run before deleting a VerseRow (and using its real Id):
DELETE FROM TokenComponent WHERE Id IN
(
    SELECT DISTINCT tco.Id
    FROM TokenComponent tco
    JOIN TokenCompositeTokenAssociation tca on tca.TokenCompositeId = tco.Id
    JOIN TokenComponent tc on tca.TokenId = tc.Id
    JOIN VerseRow vr on tc.VerseRowId = vr.Id
    WHERE vr.Id = '[... some id ...]'
)
         */
        return
            async (ProjectDbContext projectDbContext, ILogger logger, CancellationToken cancellationToken) => {

                await projectDbContext.TokenComposites
                    .Where(tc => tc.TokenCompositeTokenAssociations
                        .Where(tca => tca.Token!.VerseRowId == verseRowId).Any())
                    .ExecuteDeleteAsync(cancellationToken);

            };
    }

    public static ProjectDbContextMergeQueryAsync GetDeleteTokenComponentsByVerseRowIdQuery(Guid verseRowId)
    {
        return
            async (ProjectDbContext projectDbContext, ILogger logger, CancellationToken cancellationToken) => {

                await projectDbContext.TokenComponents
                    .Where(tc => tc.VerseRowId == verseRowId)
                    .ExecuteDeleteAsync(cancellationToken);

            };
    }

    public override async Task HandleModifyPropertiesAsync<T>(IModelDifference<T> modelDifference, T itemToModify, CancellationToken cancellationToken = default)
    {
        await base.HandleModifyPropertiesAsync<T>(modelDifference, itemToModify, cancellationToken);

        if (typeof(T).IsAssignableTo(typeof(IModelSnapshot<Models.TokenComposite>)))
        {
            // If the modifications included changes to which tokens were part of
            // the composite, we need to do two things:
            //  - remove the previous child tokens
            //  - add the new child tokens

            var tokenLocationDifference = modelDifference.PropertyDifferences
                .Where(pd => pd.PropertyName == "TokenLocations")
                .Where(pd => pd.PropertyValueDifference.GetType().IsAssignableTo(typeof(ListDifference<string>)))
                .FirstOrDefault();
            if (tokenLocationDifference is null)
            {
                return;
            }

            var snapshot = (IModelSnapshot<Models.TokenComposite>)itemToModify;
            var valueListDifference = (ListDifference<string>)tokenLocationDifference.PropertyValueDifference;
            var tokenLocationsOnlyIn1 = valueListDifference.ListMembershipDifference.OnlyIn1;
            var tokenLocationsOnlyIn2 = valueListDifference.ListMembershipDifference.OnlyIn2;

            await _mergeContext.MergeBehavior.RunProjectDbContextQueryAsync(
                $"Applying TokenComposite 'TokenLocations' property ListMembershipDifference (OnlyIn1: {string.Join(", ", tokenLocationsOnlyIn1)}, OnlyIn2: {string.Join(", ", tokenLocationsOnlyIn2)})", 
                async (ProjectDbContext projectDbContext, ILogger logger, CancellationToken cancellationToken) => {

                    var tokenCompositeId = (Guid)snapshot.EntityPropertyValues["Id"]!;
                    var tokenizedCorpusId = (Guid)snapshot.EntityPropertyValues["TokenizedCorpusId"]!;

                    var tokenLocationMap = projectDbContext.Tokens
                        .Where(e => e.TokenizedCorpusId == tokenizedCorpusId)
                        .Where(e => tokenLocationsOnlyIn1.Union(tokenLocationsOnlyIn2).Contains(e.EngineTokenId))
                        .ToDictionary(e => e.EngineTokenId!, e => e.Id);

                    var leftover = tokenLocationMap.Keys.Except(tokenLocationsOnlyIn1.Union(tokenLocationsOnlyIn2));
                    if (leftover.Any())
                    {
                        throw new PropertyResolutionException($"Tokenized corpus {tokenizedCorpusId} does not contain tokens: {string.Join(", ", leftover)}");
                    }

                    // Remove the OnlyIn1 tokens from the composite:
                    var tokenIdsOnlyIn1 = tokenLocationMap
                                .Where(l => tokenLocationsOnlyIn1.Contains(l.Key))
                                .Select(l => l.Value)
                                .ToList();
                    var tokenAssocationsToRemove = projectDbContext.TokenCompositeTokenAssociations
                            .Where(a => tokenIdsOnlyIn1.Contains(a.TokenId));

                    projectDbContext.RemoveRange(tokenAssocationsToRemove);

                    // Add the OnlyIn2 tokens to the composite:
                    var tokenAssocationsToAdd = tokenLocationMap
                        .Where(l => tokenLocationsOnlyIn2.Contains(l.Key)).ToList()
                        .Select(l => new Models.TokenCompositeTokenAssociation
                        {
                            TokenId = l.Value,
                            TokenCompositeId = tokenCompositeId
                        })
                        .ToList();

                    projectDbContext.TokenCompositeTokenAssociations.AddRange(tokenAssocationsToAdd);
            });
        }
        else
        {
            throw new NotImplementedException($"Derived merge handler with '{typeof(T).ShortDisplayName()}' model-specific HandleModifyProperties functionality");
        }
    }

    public Expression<Func<Models.TokenComposite, bool>> BuildTokenChildWhereExpression(IModelSnapshot<Models.TokenComposite> snapshot, Guid tokenizedCorpusId, IEnumerable<string> tokenLocations)
    {
        return e => e.GetType() == typeof(Models.Token) &&
                    e.TokenizedCorpusId == tokenizedCorpusId &&
                    tokenLocations.Contains(e.EngineTokenId);
    }
}


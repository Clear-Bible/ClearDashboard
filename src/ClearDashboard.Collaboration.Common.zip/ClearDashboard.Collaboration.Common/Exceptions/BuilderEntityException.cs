﻿using System;
namespace ClearDashboard.Collaboration.Exceptions;

public class BuilderEntityException : Exception
{
	public BuilderEntityException(string message) : base(message)
    {
	}
}

